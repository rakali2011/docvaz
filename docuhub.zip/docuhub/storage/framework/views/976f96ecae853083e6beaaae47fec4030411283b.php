<aside class="sidebar-left border-right bg-white shadow" id="leftSidebar" data-simplebar>
    <a href="#" class="btn collapseSidebar toggle-btn d-lg-none text-muted ml-2 mt-3" data-toggle="toggle">
      <i class="fe fe-x"><span class="sr-only"></span></i>
    </a>
    <nav class="vertnav navbar navbar-light">
      <!-- nav bar -->
      <div class="w-100 mb-4 d-flex" >
        <a class="navbar-brand mx-auto mt-2 flex-fill text-center" href="<?php echo e(route('home')); ?>">
            
          <svg version="1.1" id="logo" class="navbar-brand-img brand-sm" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 120 120" xml:space="preserve">
            <g>
              <polygon class="st0" points="78,105 15,105 24,87 87,87 	" />
              <polygon class="st0" points="96,69 33,69 42,51 105,51 	" />
              <polygon class="st0" points="78,33 15,33 24,15 87,15 	" />
            </g>
          </svg>
        </a>
      </div>
      <ul class="navbar-nav flex-fill w-100 mb-2">
        <li class="nav-item w-100">
          <a class="nav-link" id="dashboard" href="<?php echo e(route('home')); ?>">
            <i class="fe fe-home fe-16"></i>
            <span class="ml-3 item-text">Dashboard</span>
          </a>
        </li>

      </ul>
      <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'dev')): ?>
      <p class="text-muted nav-heading mt-4 mb-1"  style="text-align: center; width: 100%;">
        <span>Dev</span>
        <ul class="navbar-nav flex-fill w-100 mb-2">
          <li class="nav-item dropdown">
            <a href="#ui" id="dev-tools" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle nav-link menu">
              <i class="fe fe-box fe-16"></i>
              <span class="ml-3 item-text">Dev Management</span>
            </a>
            <ul class="collapse list-unstyled pl-4 w-100" id="ui">
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="companies" href="<?php echo e(route('companies')); ?>"><span class="ml-1 item-text">Companies</span>
                </a>
                <a class="nav-link pl-3 sub-menu" id="superadmins" href="<?php echo e(route('superadmins')); ?>"><span class="ml-1 item-text">Super Admins</span>
                </a>
                <a class="nav-link pl-3 sub-menu" id="permissions" href="<?php echo e(route('permissions')); ?>"><span class="ml-1 item-text">Permissions</span>
                </a>
              </li>



            </ul>
          </li>

        </ul>
      </p>
      <?php endif; ?>

      
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view role')): ?>

      <p class="text-muted nav-heading mt-4 mb-1"  style="text-align: center; width: 100%;">
        <span>Administration</span>
      </p>
        <ul class="navbar-nav flex-fill w-100 mb-2">
          <li class="nav-item dropdown">
            <a href="#role-management-sub" id="role-management" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle nav-link menu">
              <i class="fe fe-box fe-16"></i>
              <span class="ml-3 item-text">Roles Management</span>
            </a>
            <ul class="collapse list-unstyled pl-4 w-100" id="role-management-sub">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view role')): ?>
                <li class="nav-item">
                    <a class="nav-link pl-3 sub-menu" id="roles" href="<?php echo e(route('roles')); ?>"><span class="ml-1 item-text">Roles</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
          </li>

        </ul>

      <?php endif; ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view user')): ?>
        <ul class="navbar-nav flex-fill w-100 mb-2">
          <li class="nav-item dropdown">
            <a href="#user-management-sub" id="user-management" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle nav-link menu">
              <i class="fe fe-box fe-16"></i>
              <span class="ml-3 item-text">Users Management</span>
            </a>
            <ul class="collapse list-unstyled pl-4 w-100" id="user-management-sub">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view user')): ?>
                <li class="nav-item">
                    <a class="nav-link pl-3 sub-menu" id="users" href="<?php echo e(route('users')); ?>"><span class="ml-1 item-text">Users</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
          </li>

        </ul>

      <?php endif; ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view client','view practice'])): ?>
        <ul class="navbar-nav flex-fill w-100 mb-2">
          <li class="nav-item dropdown">
            <a href="#client-management-sub" id="client-management" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle nav-link menu">
              <i class="fe fe-box fe-16"></i>
              <span class="ml-3 item-text">Client Management</span>
            </a>
            <ul class="collapse list-unstyled pl-4 w-100" id="client-management-sub">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view client')): ?>
                <li class="nav-item">
                    <a class="nav-link pl-3 sub-menu" id="clients" href="<?php echo e(route('clients')); ?>"><span class="ml-1 item-text">Clients</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view practice')): ?>
                <li class="nav-item">
                    <a class="nav-link pl-3 sub-menu" id="practices" href="<?php echo e(route('practices')); ?>"><span class="ml-1 item-text">Practices</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
          </li>

        </ul>

      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view team'])): ?>
        <ul class="navbar-nav flex-fill w-100 mb-2">
          <li class="nav-item dropdown">
            <a href="#general-management-sub" id="general-management" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle nav-link menu">
              <i class="fe fe-box fe-16"></i>
              <span class="ml-3 item-text">General Management</span>
            </a>
            <ul class="collapse list-unstyled pl-4 w-100" id="general-management-sub">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view team')): ?>
                <li class="nav-item">
                    <a class="nav-link pl-3 sub-menu" id="teams" href="<?php echo e(route('teams')); ?>"><span class="ml-1 item-text">Teams</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view department')): ?>
                <li class="nav-item">
                    <a class="nav-link pl-3 sub-menu" id="departments" href="<?php echo e(route('departments')); ?>"><span class="ml-1 item-text">Departments</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
          </li>

        </ul>

      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['import file', 'view file'])): ?>
        <ul class="navbar-nav flex-fill w-100 mb-2">
          <li class="nav-item dropdown">
            <a href="#files-management-sub" id="files-management" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle nav-link menu">
              <i class="fe fe-box fe-16"></i>
              <span class="ml-3 item-text">Files</span>
            </a>
            <ul class="collapse list-unstyled pl-4 w-100" id="files-management-sub">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('import file')): ?>
                <li class="nav-item">
                    <a class="nav-link pl-3 sub-menu" id="import" href="<?php echo e(route('import')); ?>"><span class="ml-1 item-text">Import</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view file')): ?>
                <li class="nav-item">
                    <a class="nav-link pl-3 sub-menu" id="files" href="<?php echo e(route('files')); ?>"><span class="ml-1 item-text">Files</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
          </li>

        </ul>

      <?php endif; ?>


    </nav>
  </aside>
<?php /**PATH C:\wamp64\www\docuhub\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>