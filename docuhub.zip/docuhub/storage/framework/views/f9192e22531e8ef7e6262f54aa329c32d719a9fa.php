<script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
<div class="card shadow mb-4">

<style>
    .chat_user{
        font-size: x-large;
    font-weight: bold;
    color: #1b68ff;
    }
    .discussion-box{
        max-height: 300px;
    /* overflow-x: auto; */
    overflow-y: auto;
    overflow-x: hidden;
    }
</style>
    <div class="card-header">
        <strong class="card-title">Discussions</strong>
        
    </div>
    <div class="card-body">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('discussion.discussion-box', ['project_id' => $project_id])->html();
} elseif ($_instance->childHasBeenRendered('l111668766-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l111668766-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l111668766-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l111668766-0');
} else {
    $response = \Livewire\Livewire::mount('discussion.discussion-box', ['project_id' => $project_id]);
    $html = $response->html();
    $_instance->logRenderedChild('l111668766-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('discussion.send-message', ['project_id' => $project_id])->html();
} elseif ($_instance->childHasBeenRendered('l111668766-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l111668766-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l111668766-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l111668766-1');
} else {
    $response = \Livewire\Livewire::mount('discussion.send-message', ['project_id' => $project_id]);
    $html = $response->html();
    $_instance->logRenderedChild('l111668766-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div> <!-- .card-body -->
</div> <!-- .card -->
<script>
    window.addEventListener('new_message', event=>{
        $('.discussion-box').scrollTop($('.discussion-box')[0].scrollHeight);

    });
    $('.discussion-box').scrollTop($('.discussion-box')[0].scrollHeight);
</script>
<?php /**PATH C:\xampp\htdocs\Archiwiz\resources\views/livewire/discussion/main.blade.php ENDPATH**/ ?>