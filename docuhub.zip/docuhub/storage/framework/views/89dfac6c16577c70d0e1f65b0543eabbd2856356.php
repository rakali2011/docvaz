<aside class="sidebar-left border-right bg-white shadow" id="leftSidebar" data-simplebar>
    <a href="#" class="btn collapseSidebar toggle-btn d-lg-none text-muted ml-2 mt-3" data-toggle="toggle">
      <i class="fe fe-x"><span class="sr-only"></span></i>
    </a>
    <nav class="vertnav navbar navbar-light">
      <!-- nav bar -->
      <div class="w-100 mb-4 d-flex" >
        <a class="navbar-brand mx-auto mt-2 flex-fill text-center" href="<?php echo e(route('home')); ?>">
            
          <svg version="1.1" id="logo" class="navbar-brand-img brand-sm" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 120 120" xml:space="preserve">
            <g>
              <polygon class="st0" points="78,105 15,105 24,87 87,87 	" />
              <polygon class="st0" points="96,69 33,69 42,51 105,51 	" />
              <polygon class="st0" points="78,33 15,33 24,15 87,15 	" />
            </g>
          </svg>
        </a>
      </div>
      <ul class="navbar-nav flex-fill w-100 mb-2">
        <li class="nav-item w-100">
          <a class="nav-link" id="dashboard" href="<?php echo e(route('home')); ?>">
            <i class="fe fe-home fe-16"></i>
            <span class="ml-3 item-text">Dashboard</span>
          </a>
        </li>

      </ul>
      <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'super admin')): ?>
      <p class="text-muted nav-heading mt-4 mb-1"  style="text-align: center; width: 100%;">
        <span>Super Admin</span>
        <ul class="navbar-nav flex-fill w-100 mb-2">
          <li class="nav-item dropdown">
            <a href="#ui" id="user-management" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle nav-link menu">
              <i class="fe fe-box fe-16"></i>
              <span class="ml-3 item-text">User Management</span>
            </a>
            <ul class="collapse list-unstyled pl-4 w-100" id="ui">
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="add-user" href="<?php echo e(route('add_user')); ?>"><span class="ml-1 item-text">Add User</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="workers" href="<?php echo e(route('workers')); ?>"><span class="ml-1 item-text">Workers</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="clients" href="<?php echo e(route('clients')); ?>"><span class="ml-1 item-text">Clients</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="admins" href="<?php echo e(route('admins')); ?>"><span class="ml-1 item-text">Admins</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="vendors" href="<?php echo e(route('vendors')); ?>"><span class="ml-1 item-text">Vendors</span>
                </a>
              </li>
              
            </ul>
          </li>
          
        </ul>
      </p>
      <?php endif; ?>
      <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'client|super admin|admin')): ?>
      <p class="text-muted nav-heading mt-4 mb-1"  style="text-align: center; width: 100%;">
        <span>Services</span>
        <ul class="navbar-nav flex-fill w-100 mb-2">
          <li class="nav-item dropdown">
            <a href="#bim" id="Archiwiz-BIM" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle nav-link menu">
              <i class="fe fe-box fe-16"></i>
              <span class="ml-3 item-text">Archiwiz BIM</span>
            </a>
            <ul class="collapse list-unstyled pl-4 w-100" id="bim">
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="Archiwiz-BIM-new-build" href="<?php echo e(route('bim.new_build')); ?>"><span class="ml-1 item-text">New Build</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="Archiwiz-BIM-renovation" href="<?php echo e(route('bim.renovation')); ?>"><span class="ml-1 item-text">Renovation</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="Archiwiz-BIM-as-build" href="<?php echo e(route('bim.as_build')); ?>"><span class="ml-1 item-text">As Build</span>
                </a>
              </li>


            </ul>
          </li>
          <li class="nav-item dropdown">
            <a href="#vu" id="Archiwiz-Visualization" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle nav-link menu">
              <i class="fe fe-box fe-16"></i>
              <span class="ml-3 item-text">Archiwiz Visualization</span>
            </a>
            <ul class="collapse list-unstyled pl-4 w-100" id="vu">
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="Archiwiz-Visualization-new-build" href="<?php echo e(route('vu.new_build')); ?>"><span class="ml-1 item-text">New Build</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="Archiwiz-Visualization-renovation" href="<?php echo e(route('vu.renovation')); ?>"><span class="ml-1 item-text">Renovation</span>
                </a>
              </li>



            </ul>
          </li>
          <li class="nav-item dropdown">
            <a href="#Scanning" id="Archiwiz-Scanning" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle nav-link menu">
              <i class="fe fe-box fe-16"></i>
              <span class="ml-3 item-text">Archiwiz Scanning</span>
            </a>
            <ul class="collapse list-unstyled pl-4 w-100" id="Scanning">
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="Archiwiz-Scanning-new-build" href="<?php echo e(route('scanning.new_build')); ?>"><span class="ml-1 item-text">New Build</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="Archiwiz-Scanning-renovation" href="<?php echo e(route('scanning.renovation')); ?>"><span class="ml-1 item-text">Renovation</span>
                </a>
              </li>



            </ul>
          </li>
          <li class="nav-item dropdown">
            <a href="#Construction" id="Archiwiz-Construction" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle nav-link menu">
              <i class="fe fe-box fe-16"></i>
              <span class="ml-3 item-text">Archiwiz Construction</span>
            </a>
            <ul class="collapse list-unstyled pl-4 w-100" id="Construction">
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="Archiwiz-Construction-new-build" href="<?php echo e(route('construction.new_build')); ?>"><span class="ml-1 item-text">New Build</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="Archiwiz-Construction-renovation" href="<?php echo e(route('construction.renovation')); ?>"><span class="ml-1 item-text">Renovation</span>
                </a>
              </li>



            </ul>
          </li>

        </ul>
      </p>
      <?php endif; ?>
      <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin|super admin|vendor|worker')): ?>
      <p class="text-muted nav-heading mt-4 mb-1"  style="text-align: center; width: 100%;">
        <span>Projects</span>
        <ul class="navbar-nav flex-fill w-100 mb-2">
          <li class="nav-item dropdown">
            <a href="#Projects" id="Archiwiz-Projects" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle nav-link menu">
              <i class="fe fe-box fe-16"></i>
              <span class="ml-3 item-text">Archiwiz Projects</span>
            </a>
            <ul class="collapse list-unstyled pl-4 w-100" id="Projects">
              <li class="nav-item">
                <a class="nav-link pl-3 sub-menu" id="Archiwiz-my-projects" href="<?php echo e(route('my_projects')); ?>"><span class="ml-1 item-text">My Projects</span>
                </a>
              </li>
            </ul>
          </li>


        </ul>
      </p>
      <?php endif; ?>


      
    </nav>
  </aside>
<?php /**PATH C:\xampp\htdocs\Archiwiz\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>