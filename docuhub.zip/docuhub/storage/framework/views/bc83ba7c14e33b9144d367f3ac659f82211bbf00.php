<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-12">
        <span class="mb-2 page-title menu-head">Practices</span>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add practice')): ?>
        <a class="btn btn-primary float-right" href="<?php echo e(route('add_practice')); ?>">Create Practice</a>

        <?php endif; ?>
        <p class="card-text"></p>
        <div class="row my-4">
          <!-- Small table -->
          <div class="col-md-12">
            <div class="card shadow">
              <div class="card-body">
                <!-- table -->
                <table class="table datatables" id="dataTable-1">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'dev')): ?>
                      <th>Company</th>
                      <?php endif; ?>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                        <?php $__currentLoopData = $practices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->name); ?></td>
                            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'dev')): ?>
                            <td><?php echo e(@$item->company->name); ?></td>
                            <?php endif; ?>
                            <td>
                            <button class="btn btn-sm dropdown-toggle more-horizontal" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="text-muted sr-only">Action</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update practice')): ?>
                            <a class="dropdown-item" href="#">Edit</a>
                            <?php endif; ?>

                            </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div> <!-- simple table -->
        </div> <!-- end section -->
      </div> <!-- .col-12 -->
    </div> <!-- .row -->
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\docuhub\resources\views/practice_management/practices.blade.php ENDPATH**/ ?>