<?php $__env->startSection('content'); ?>


    <h3>Dashboard</h3>
    



<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\docuhub\resources\views/welcome.blade.php ENDPATH**/ ?>