<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-12">
        <span class="mb-2 page-title menu-head"><?php echo e($data['page']); ?></span>
        <p class="card-text"></p>

      </div> <!-- .col-12 -->
      <div class="col-12">
        <div class="row align-items-center mb-4">
          
          
        </div> <!-- .row -->
        <div class="row my-4">
          <div class="col-md-9">
            <div class="card shadow mb-4">
              <div class="card-header">
                <strong class="card-title"><?php echo e($project->name); ?></strong>
                
              </div>
              <div class="card-body">
                <dl class="row align-items-center mb-0">
                  <dt class="col-sm-2 mb-3 text-muted">Created by</dt>
                  <dd class="col-sm-4 mb-3">
                    <strong><?php echo e($project->user->fullname); ?></strong>
                  </dd>
                  <dt class="col-sm-2 mb-3 text-muted">Status</dt>
                  <dd class="col-sm-4 mb-3">
                    <strong><?php echo e(project_status($project->status)); ?></strong>
                  </dd>
                  
                </dl>
                <dl class="row mb-0">
                  
                  <dt class="col-sm-2 mb-3 text-muted">Created On</dt>
                  <dd class="col-sm-4 mb-3"><?php echo e($project->created_at->format('M d Y - h:i A')); ?></dd>
                  <dt class="col-sm-2 mb-3 text-muted">Last Update</dt>
                  <dd class="col-sm-4 mb-3"><?php echo e($project->updated_at->format('M d Y - h:i A')); ?></dd>
                  <dt class="col-sm-2 text-muted">Location</dt>
                  <dd class="col-sm-10"> <?php echo e($project->location); ?> </dd>

                </dl>

                <div class="row mt-3">
                    <div class="col-12">
                        <h3 >Files</h3>
                    </div>

                    <div class="col-md-12">
                      <?php if(count($project->files) > 0): ?>



                      <table class="table table-borderless table-striped">
                        <thead>
                          <tr>
                            <th></th>
                            <th class="w-50">Name</th>
                            <th>Type</th>
                            <th>Last Update</th>
                            <th></th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $project->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td class="text-center">
                              <div class="circle circle-sm bg-light">
                                <span class="fe fe-archive fe-16 text-muted"></span>
                              </div>
                              
                            </td>
                            <th scope="row"><?php echo e($file->org_name); ?><br />
                              <span class="badge badge-light text-muted mr-2"><?php echo e($file->size); ?></span>
                              <span class="badge badge-light text-muted"><?php echo e($file->ext); ?></span>
                            </th>
                            <td class="text-muted"> <?php echo e(file_type($file->type)); ?> </td>
                            <td class="text-muted"><?php echo e($file->updated_at->format('M d Y - h:i A')); ?></td>
                            <td>
                              <div class="file-action">
                                <button type="button" class="btn btn-link dropdown-toggle more-vertical p-0 text-muted mx-auto" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  <span class="text-muted sr-only">Action</span>
                                </button>
                                <div class="dropdown-menu m-2">
                                  
                                  <a class="dropdown-item" target="_blank" href="<?php echo e(route('download', ['id' => Crypt::encrypt($file->id)])); ?>"><i class="fe fe-download fe-12 mr-4"></i>Download</a>
                                </div>
                              </div>
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>

                      <?php else: ?>
                      <h4 class="text-center">No Files</h4>
                      <?php endif; ?>

                    </div>


                </div>
              </div> <!-- .card-body -->
            </div> <!-- .card -->

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('discussion.main',['project_id' => $project->id])->html();
} elseif ($_instance->childHasBeenRendered('lfeeFYP')) {
    $componentId = $_instance->getRenderedChildComponentId('lfeeFYP');
    $componentTag = $_instance->getRenderedChildComponentTagName('lfeeFYP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lfeeFYP');
} else {
    $response = \Livewire\Livewire::mount('discussion.main',['project_id' => $project->id]);
    $html = $response->html();
    $_instance->logRenderedChild('lfeeFYP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
          </div> <!-- .col-md -->
          <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'super admin|admin')): ?>
          <div class="col-md-3">
            <div class="card shadow mb-4">

              <div class="card-body">
                <form action="<?php echo e(route('assign_project', ['id' => Crypt::encrypt($project->id)])); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <label for="multi-select2">Assignments</label>
                    <select name="users[]" class="form-control select2-multi" id="multi-select2" multiple>
                      <?php
                          $vendors = vendors();
                          $workers = workers();

                      ?>
                      <?php if(count($vendors) > 0): ?>
                      <optgroup label="Vendors">
                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e((check_assignment($vendor->id, $project->id))?'selected':''); ?> value="<?php echo e($vendor->id); ?>"><?php echo e($vendor->fullname); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                      </optgroup>
                      <?php endif; ?>
                      <?php if(count($workers) > 0): ?>
                      <optgroup label="Workers">
                        <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e((check_assignment($worker->id, $project->id))?'selected':''); ?> value="<?php echo e($worker->id); ?>"><?php echo e($worker->fullname); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                      </optgroup>
                      <?php endif; ?>

                    </select>
                  </div>
                  <div class="form-group">
                    <label for="status">Status</label>
                    <select name="status" class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status">
                      <option value="0" <?php echo e(($project->status == 0)?'selected':''); ?>>Pending</option>
                      <option value="1" <?php echo e(($project->status == 1)?'selected':''); ?>>Approved</option>
                      <option value="2" <?php echo e(($project->status == 2)?'selected':''); ?>>In-Progress</option>
                      <option value="3" <?php echo e(($project->status == 3)?'selected':''); ?>>On Hold</option>
                      <option value="4" <?php echo e(($project->status == 4)?'selected':''); ?>>Completed</option>
                      <option value="5" <?php echo e(($project->status == 5)?'selected':''); ?>>Rejected</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" style="display: block" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <button type="submit" class="btn btn-primary">Submit</button>
                </form>
              </div>
            </div>
          </div> <!-- .col-md -->
          <?php endif; ?>
          
        </div> <!-- .col-md -->
      </div>
    </div> <!-- .row -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Archiwiz\resources\views/portal/view_project.blade.php ENDPATH**/ ?>