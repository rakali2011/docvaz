<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row ">
      <div class="col-12 mb-3">
        <span class="mb-2 page-title menu-head">Dashboard</span>
        <p class="card-text"></p>

      </div> <!-- .col-12 -->
      <div class="col-md-6 col-xl-3 mb-4">
        <div class="card shadow">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col-3 text-center">
                <span class="circle circle-sm bg-primary">
                  <i class="fe fe-16 fe-shopping-cart text-white mb-0"></i>
                </span>
              </div>
              <div class="col pr-0">
                <p class="small text-muted mb-0">Bim</p>
                <span class="h3 mb-0"><?php echo e($data['bim']); ?></span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-xl-3 mb-4">
        <div class="card shadow">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col-3 text-center">
                <span class="circle circle-sm bg-primary">
                  <i class="fe fe-16 fe-shopping-cart text-white mb-0"></i>
                </span>
              </div>
              <div class="col pr-0">
                <p class="small text-muted mb-0">Visualisation</p>
                <span class="h3 mb-0"><?php echo e($data['vu']); ?></span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-xl-3 mb-4">
        <div class="card shadow">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col-3 text-center">
                <span class="circle circle-sm bg-primary">
                  <i class="fe fe-16 fe-shopping-cart text-white mb-0"></i>
                </span>
              </div>
              <div class="col pr-0">
                <p class="small text-muted mb-0">Scanning</p>
                <span class="h3 mb-0"><?php echo e($data['scanning']); ?></span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-xl-3 mb-4">
        <div class="card shadow">
          <div class="card-body">
            <div class="row align-items-center">
              <div class="col-3 text-center">
                <span class="circle circle-sm bg-primary">
                  <i class="fe fe-16 fe-shopping-cart text-white mb-0"></i>
                </span>
              </div>
              <div class="col pr-0">
                <p class="small text-muted mb-0">Construction</p>
                <span class="h3 mb-0"><?php echo e($data['construction']); ?></span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6 col-xl-6 mb-4">
        <div class="card shadow mb-4">
            <div class="card-header">
              <strong>Services</strong>
            </div>
            <div class="card-body">
              <div class="mb-2">
                <div id="pieChartWidget"></div>
              </div>
              
            </div> <!-- card-body -->
          </div>
      </div>
      <div class="col-md-6 col-xl-6 mb-4">
        <div class="card shadow mb-4">
            <div class="card-header">
              <strong>Status</strong>
            </div>
            <div class="card-body">
              <div class="mb-2">
                <div id="pieChartWidgetstatus"></div>
              </div>
              
            </div> <!-- card-body -->
          </div>
      </div>

    </div> <!-- .row -->
</div>
<?php $__env->startPush('scripts'); ?>
<script>
     var pieChartWidget,
    pieChartWidgetOptions = {
        series: [<?php echo e($data['bim']); ?>, <?php echo e($data['vu']); ?>, <?php echo e($data['scanning']); ?>,<?php echo e($data['construction']); ?>],
        chart: {
            type: "donut",
            height: 160,
            zoom: { enabled: !1 },
            toolbar: { show: !1 },
        },
        theme: { mode: colors.chartTheme },
        plotOptions: { pie: { donut: { size: "0" }, expandOnClick: !1 } },
        labels: ["Bim", "Visualisation", "Scanning", "Construction"],
        dataLabels: {
            enabled: !0,
            style: {
                fontSize: "10px",
                fontFamily: base.defaultFontFamily,
                fontWeight: "300",
            },
        },
        legend: { show: !1 },
        stroke: {
            show: !1,
            colors: extend.primaryColorLight,
            width: 1,
            dashArray: 0,
        },
        fill: { opacity: 1, colors: chartColors },
    },
    pieChartWidgetCtn = document.querySelector("#pieChartWidget");
pieChartWidgetCtn &&
    (pieChartWidget = new ApexCharts(
        pieChartWidgetCtn,
        pieChartWidgetOptions
    )).render();
     var pieChartWidget,
    pieChartWidgetOptions = {
        series: [<?php echo e($data['pending']); ?>, <?php echo e($data['inprogress']); ?>, <?php echo e($data['onhold']); ?>,<?php echo e($data['completed']); ?>,<?php echo e($data['rejected']); ?>],
        chart: {
            type: "donut",
            height: 160,
            zoom: { enabled: !1 },
            toolbar: { show: !1 },
        },
        theme: { mode: colors.chartTheme },
        plotOptions: { pie: { donut: { size: "0" }, expandOnClick: !1 } },
        labels: ["Pending", "In Progress", "Onhold", "Completed","Rejected"],
        dataLabels: {
            enabled: !0,
            style: {
                fontSize: "10px",
                fontFamily: base.defaultFontFamily,
                fontWeight: "300",
            },
        },
        legend: { show: !1 },
        stroke: {
            show: !1,
            colors: extend.primaryColorLight,
            width: 1,
            dashArray: 0,
        },
        fill: { opacity: 1, colors: chartColors },
    },
    pieChartWidgetCtn = document.querySelector("#pieChartWidgetstatus");
pieChartWidgetCtn &&
    (pieChartWidget = new ApexCharts(
        pieChartWidgetCtn,
        pieChartWidgetOptions
    )).render();
</script>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Archiwiz\resources\views/portal/admin_dashboard.blade.php ENDPATH**/ ?>