<div class="discussion-box" wire:poll>
<?php if(count($disussions) > 0): ?>
    <?php $__currentLoopData = $disussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disussion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div wire:key="<?php echo e($disussion->id); ?>" class="row align-items-center mb-4 ">
        <div class="col-auto">
            <div class="avatar avatar-sm mb-3 mx-4 chat_user">
                <?php echo e($disussion->user->initials); ?>

                
            </div>
        </div>
        <div class="col">
            <strong><?php echo e($disussion->user->fullname); ?></strong>
            <div class="mb-2"><?php echo e($disussion->message); ?></div>
            <small class="text-muted"><?php echo e($disussion->created_at->format('M d Y - h:i A')); ?></small>
        </div>
        
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<h4>No Message yet</h4>
<?php endif; ?>
</div>

<?php /**PATH C:\xampp\htdocs\Archiwiz\resources\views/livewire/discussion/discussion-box.blade.php ENDPATH**/ ?>