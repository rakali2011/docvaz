<?php return array (
  'discussion.discussion-box' => 'App\\Http\\Livewire\\Discussion\\DiscussionBox',
  'discussion.main' => 'App\\Http\\Livewire\\Discussion\\Main',
  'discussion.send-message' => 'App\\Http\\Livewire\\Discussion\\SendMessage',
);