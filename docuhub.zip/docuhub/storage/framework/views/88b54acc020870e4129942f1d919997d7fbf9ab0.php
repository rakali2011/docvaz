<div>
<hr class="my-4">
<h6 class="mb-3">Response</h6>

<form wire:submit.prevent="submit" method="POST">

    <div class="form-group">
        <label for="exampleFormControlTextarea1" class="sr-only">Your Message</label>
        <textarea wire:model="message" class="form-control bg-light" id="exampleFormControlTextarea1" rows="2"></textarea>
    </div>
    <div class="justify-content-between align-items-center">
        
        <button type="submit" class="btn btn-primary" style="float: right">Send</button>
    </div>
</form>
</div>
<?php /**PATH C:\xampp\htdocs\Archiwiz\resources\views/livewire/discussion/send-message.blade.php ENDPATH**/ ?>