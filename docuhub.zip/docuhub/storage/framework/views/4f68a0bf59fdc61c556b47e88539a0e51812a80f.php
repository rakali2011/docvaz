<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-12">
        <h2 class="page-title menu-head"><?php echo e($data['page']); ?></h2>
        <div class="card shadow mb-4">
        <?php if(@$project): ?>
        <form action="<?php echo e(route(get_route($data['service_type'], $data['service_sub_type'], 'save'), ['id' => Crypt::encrypt($project->id)])); ?>" method="POST" enctype="multipart/form-data">
        <?php else: ?>
        <form action="<?php echo e(route(get_route($data['service_type'], $data['service_sub_type'], 'save'))); ?>" method="POST" enctype="multipart/form-data">
        <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group mb-3">
                    <label for="name">Name</label>
                    <input name="name" value="<?php echo e((@$project)?@$project->name:old('name')); ?>" required type="text" id="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group mb-3">
                    <label for="location">Location</label>
                    <input name="location" value="<?php echo e((@$project)?@$project->location:old('location')); ?>" required type="text" id="location" class="form-control <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                    <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="col-12">
                    <h5>File Type</h5>
                </div>
                <div class="col-md-6">
                  <div class="form-group mb-3">
                    <label for="cad">Cad</label>
                    <input type="radio" value="1" <?php echo e((@$project->drawing_type == '1')?'checked':''); ?> required <?php echo e((old('file_type') == '1')?'checked':''); ?> name="file_type" value="cad" id="cad" class="form-control <?php $__errorArgs = ['file_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                    <?php $__errorArgs = ['file_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                </div>
                <div class="col-md-6">
                  <div class="form-group mb-3">
                    <label for="drawing">Architectural Drawing</label>
                    <input type="radio" value="0" <?php echo e((@$project->drawing_type == '0')?'checked':''); ?> required <?php echo e((old('file_type') == '0')?'checked':''); ?> name="file_type" id="drawing" class="form-control">
                  </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group mb-3">
                      <label for="structural">Structural Diagram</label>
                      <input type="file" name="structural" id="structural" class="form-control <?php $__errorArgs = ['structural'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                      <?php $__errorArgs = ['structural'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if(@$project->structural): ?>
                    <table>
                        <tbody>
                            <tr>
                                <td>
                                    <a  style="word-break: break-all" href="<?php echo e(route('download', ['id' => Crypt::encrypt($project->structural->id)])); ?>"><?php echo e($project->structural->org_name); ?></a>
                                </td>
                                <td>
                                    <a onclick="confirm('Are you sure you want to delete this?')" href="<?php echo e(route('delete_file', ['id' => Crypt::encrypt($project->structural->id)])); ?>">
                                    <i class="fe fe-trash"></i>
                                    </a>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                      <label for="architectural">Architectural Diagram</label>
                      <input type="file" name="architectural" id="architectural" class="form-control <?php $__errorArgs = ['architectural'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                      <?php $__errorArgs = ['architectural'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if(@$project->architectural): ?>
                    <table>
                        <tbody>
                            <tr>
                                <td>
                                    <a  style="word-break: break-all" href="<?php echo e(route('download', ['id' => Crypt::encrypt($project->architectural->id)])); ?>"><?php echo e($project->architectural->org_name); ?></a>
                                </td>
                                <td>
                                    <a onclick="confirm('Are you sure you want to delete this?')" href="<?php echo e(route('delete_file', ['id' => Crypt::encrypt($project->architectural->id)])); ?>">
                                    <i class="fe fe-trash"></i>
                                    </a>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                      <label for="mep">Mep Diagram</label>
                      <input type="file" name="mep" id="mep" class="form-control <?php $__errorArgs = ['mep'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                      <?php $__errorArgs = ['mep'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php if(@$project->mep): ?>
                    <table>
                        <tbody>
                            <tr>
                                <td>
                                    <a  style="word-break: break-all" href="<?php echo e(route('download', ['id' => Crypt::encrypt($project->mep->id)])); ?>"><?php echo e($project->mep->org_name); ?></a>
                                </td>
                                <td>
                                    <a onclick="confirm('Are you sure you want to delete this?')" href="<?php echo e(route('delete_file', ['id' => Crypt::encrypt($project->mep->id)])); ?>">
                                    <i class="fe fe-trash"></i>
                                    </a>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <div class="form-group mb-3">
                      <label for="images">Reference Images for Inspiration  </label>
                      <input type="file"  multiple name="images[]" id="images" class="form-control <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                      <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  <?php if(@$project->images): ?>
                    <table>
                        <tbody>
                            <?php $__currentLoopData = $project->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('download', ['id' => Crypt::encrypt($img->id)])); ?>"><?php echo e($img->org_name); ?></a>
                                </td>
                                <td>
                                    <a onclick="confirm('Are you sure you want to delete this?')" href="<?php echo e(route('delete_file', ['id' => Crypt::encrypt($img->id)])); ?>">
                                    <i class="fe fe-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                  <?php endif; ?>
                </div>


                <div class="col-12">
                  <input type="submit" value="<?php echo e((@$project)?'Update':'Save'); ?>" class="btn btn-success float-right">
                </div>
              </div>
            </div>
          </form>
        </div> <!-- / .card -->

      </div> <!-- .col-12 -->
    </div> <!-- .row -->
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Archiwiz\resources\views/portal/vu/create_project_new_build.blade.php ENDPATH**/ ?>