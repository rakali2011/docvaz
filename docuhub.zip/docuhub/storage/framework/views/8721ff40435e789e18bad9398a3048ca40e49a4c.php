<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
      <div class="col-12">
        <span class="mb-2 page-title menu-head">Departments</span>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add department')): ?>
        <a class="btn btn-primary float-right" href="<?php echo e(route('add_department')); ?>">Create Department</a>

        <?php endif; ?>
        <p class="card-text"></p>
        <div class="row my-4">
          <!-- Small table -->
          <div class="col-md-12">
            <div class="card shadow">
                <div class="card-header">
                    <strong>Uppy</strong>
                  </div>
              <div class="card-body">
                <form id="form" action="<?php echo e(route('upload')); ?>" enctype="multipart/form-data" method="POST">
                <?php echo csrf_field(); ?>

                <div id="uppy"></div>
                <input type="submit" value="submit">
                </form>

              </div>
            </div>
          </div> <!-- simple table -->
        </div> <!-- end section -->
      </div> <!-- .col-12 -->
    </div> <!-- .row -->
</div>
<script>

</script>
<style>
    .uppy-Dashboard-progressindicators {
    display: none;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\docuhub\resources\views/files.blade.php ENDPATH**/ ?>